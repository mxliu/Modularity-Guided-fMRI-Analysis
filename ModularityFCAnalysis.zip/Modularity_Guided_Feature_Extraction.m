%% Function
%
%     Modularity-Guided Feature Extraction
%
%% basic setting, load data, basic statistics
clc;clear;
root=cd; addpath(genpath([root '/FUN'])); addpath(genpath([root '/DATA']));
load('dataNCandeMCI.mat')
nSubj=length(dataNCandeMCI.lab);% the number of subject
nROI=size(dataNCandeMCI.data{1},2);% the number of ROIs
lab=dataNCandeMCI.lab;
DATA=dataNCandeMCI.data;

%% Functional Brain Network Construction and Find Modular Structure
Adjacency_matrix=zeros(nROI,nROI);
for i=1:nSubj
    BrainNet{i}=corrcoef(DATA{i});
    BrainNet{i}=atanh(BrainNet{i});
    BrainNet{i}(BrainNet{i}==inf)=0;
    BrainNet{i}=(BrainNet{i}+BrainNet{i}')/2;% symmetrization
    Adjacency_matrix=BrainNet{i}+Adjacency_matrix;% All networks plus sum
end
Adjacency_matrix=Adjacency_matrix/nSubj;% Take the average
k=8;%number of modules
[B,index]=sncut(Adjacency_matrix,k);% spectral clustering(ncut)

%% Adjacency Matrix Rearrangement and Design Matrix Construction
for i=1:nSubj
    line=BrainNet{i}(:,index);                           
    Re_brainNet=line(index,:);
    blk=[];group=[];
    for q=1:k
        idx=find(B==q);
        module=Re_brainNet(idx(1):idx(end),idx(1):idx(end));
        blk=blkdiag(blk,module);
        g=triu(q*ones(length(module),length(module)));
        g=reshape(g,1,length(g)^2);
        g=g(find(g~=0));
        group=[group g];
    end
    N_group=0;
    for q=1:k
        id=find(group==q);
        N_group=[N_group id(end)];
    end
     blkk=triu(blk);
     blkk=reshape(blkk,1,length(blkk)^2);
     remaining=Re_brainNet-blk;
     remaining=triu(remaining);
     remaining=reshape(remaining,1,length(remaining)^2);
     Design_matrix(i,:)=[blkk remaining];
     data(i,:)=reshape(triu(BrainNet{i}),nROI^2,1);
     a(i,:)=blkk;b(i,:)=remaining;
end
Design_matrix=Design_matrix(:,any(Design_matrix)); %
N_group=[N_group (N_group(end)+1) :1:length(Design_matrix)];
save('Feature Matrix.mat')