%% Function
%
%     Modular Structure Induced Feature Selection (MLFS)
%
%%
clc;clear;
%% load data
root=cd; addpath(genpath([root '/FUN'])); addpath(genpath([root '/Feature']));
load('Feature Matrix.mat')
data=Design_matrix;
%% ======Parameter Setting=======%%   
opts=[];
opts.init=2;        % starting from a zero point
opts.tFlag=0;       % run .maxIter iterations
opts.nFlag=0;       % without normalization
opts.rFlag=0;
% Group Property
ind=N_group;   % the indices for the groups
k=length(ind)-1;     % number of groups
opts.ind=ind;       % set the group indices
opts.q=2;           % set the value for q
opts.sWeight=[1,1]; % set the weight for positive and negative samples
opts.gWeight=ones(k,1);   % set the weight for the group, a cloumn vector
opts.mFlag=0;       % treating it as compositive function 
opts.lFlag=0;       % Nemirovski's line search
lambda=[0.01,0.1:0.1:1];      %Regularization parameter
Ntimes=100;
kfoldout=5;%Cross validation fold  number
kfoldin=5;%Inner cross validation fold  number
%%c====End====%%
%% ======Cross validation======%%
for N=1:Ntimes
    c=cvpartition(nSubj,'k',kfoldout);
    for f_out=1:c.NumTestSets
        Train_dat=data(training(c,f_out),:);
        Train_lab = lab(training(c,f_out));
        Test_dat = data(test(c,f_out),:);
        Test_lab = lab(test(c,f_out));
        [Index_out,~]=find(test(c,f_out)~=0);%%Find the location of the Subjects used in this s
        %%======Inner cross validation======%%
        for L=1:length(lambda)
            c_in=cvpartition(length(Train_lab),'k',kfoldin);%%Five-fold-cross-validation
            for f_in=1:c_in.NumTestSets
                InTrain_dat=Train_dat(training(c_in,f_in),:);
                InTrain_lab=Train_lab(training(c_in,f_in));
                Vali_dat=Train_dat(test(c_in,f_in),:);
                Vali_lab= Train_lab(test(c_in,f_in));
                %%====== Training set======%%
                [W,~, ~]= glLeastR(InTrain_dat,InTrain_lab,lambda(L),opts); %%Obtaining the coefficient
                %======The features corresponding to the coefficients that are not equal to 0 are selected======%
                W(W~=0) = 1;
                Indictor=find(W==1);%Find the location of the coefficients
                InTrain_datt=InTrain_dat(:,Indictor);
                Vali_datt=Vali_dat(:,Indictor);
                %======SVM======%
                cmd= ['-t 0 -c 1 -b 1'];% linear kernel
                model=svmtrain(InTrain_lab, InTrain_datt, cmd); % Linear Kernel
                [predict_label, accuracy_svm, prob_estimates] = svmpredict(Vali_lab, Vali_datt, model, '-b 1');
                Test_res(1,f_in)= sum(predict_label==Vali_lab)/length(Vali_lab);%accuracy;
                fprintf('Ntimes=%d,out fold=%d,lambda fold=%d, in fold=%d\n',N,f_out,L,f_in);
            end
            ACC_in(:,L)=mean(Test_res);
        end
        %======Select the best parameter======%
        [~,zmax]=find(ACC_in==max(max(ACC_in)));
        lambda_max=lambda(1,zmax);
        lambda_max=lambda_max(1,1);
        %%======Validation set======%%
        [NewW, ~, ~]= glLeastR(Train_dat,Train_lab,lambda_max, opts);
        weight(f_out,:)=NewW;
        NewW(NewW~=0) = 1;
        Abs(f_out,:)=NewW;
        Indictor=find(NewW==1);%Find the location of the coefficients
        Train_datt=Train_dat(:,Indictor);
        Test_datt=Test_dat(:,Indictor);
        %======SVM======%
         cmd = ['-t 0 -c 1 -b 1'];% linear kernel
         model = svmtrain(Train_lab, Train_datt, cmd); % Linear Kernel
         [predict_label, accuracy_svm, prob_estimates] = svmpredict(Test_lab, Test_datt, model, '-b 1');
         Test=(abs(predict_label-Test_lab));
         %======Evaluation metrics======%
         INDEX_Po=find(Test_lab==1);
         INDEX_NE=find(Test_lab==-1);
         Test_Po=Test(INDEX_Po,:);
         [TP,~]=size(find(Test_Po==0));
         [FN,~]=size(find(Test_Po==2));
         Test_Ne=Test(INDEX_NE,:);
         [FP,~]=size(find( Test_Ne==2));
         [TN,~]=size(find(Test_Ne==0));
         sen(1,f_out)=TP/(TP+FN);
         spe(1,f_out)=TN/(TN+FP);
         ratings(Index_out,1)=prob_estimates(:,1);
         acc(N,f_out)=(TP+TN)/(TP+FP+TN+FN);
    end 
    %======Take an average of 5 fold======%
    Acc(N,1)=mean(acc(N,:));sen=mean(sen);spe=mean(spe);
    Sen(N,1)=sen;Spe(N,1)=spe; ROC(:,N)=ratings;average_ROC=sum(ROC,2);
end
%======Take an average of 100 times======%
Final_ROC=average_ROC/Ntimes;
ACC=mean(Acc);SEN=mean(Sen);SPE=mean(Spe);
[~,~,~,AUC]=perfcurve(lab,Final_ROC,1);
Final_result=[ACC,SEN,SPE,AUC]
save('MLFS.mat')