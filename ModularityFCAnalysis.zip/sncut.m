function[B,index]=sncut(A,k)
%% %Construct the Signed Degree Matrix and Construct the Signed Graph Laplacian Matrix
[~,n]=size(A);
Degree = diag(sum(abs(A)));                  %%degree matrix
L=Degree-A;  
L=Degree^(-1/2)*L*Degree^(-1/2);                %%signed graph Laplacian matrix

%% % Eigenvalue Decomposition
[V,D] = eig(L);                            
[~,Index] = sort(diag(D),'ascend');
V = V(:,Index);                        

%% % Clustering and Obtain the Final Partition
V_use=V(:,1:k);                          
V_use= V_use./repmat(sqrt(diag(V_use'*V_use)'),n,1);  
[idx,~]=kmeans(V_use,k);           
[B,index] = sort(idx);
end
