function t = mytrace(A,B)

% This compute the trace inner product of two matrices A, B, of the same
% dimension.

t=sum(sum(A.*B)); 